#include "Castle.h"

Castle::Castle()
{
}

Castle::Castle(int px, int py, int pw, int ph) : Base(px, py, pw, ph, 0, 0, 0, 0)
{

}

Castle::~Castle()
{
}
