#pragma once
#include "Base.h"
class NaveMala : public Base
{
public:
	NaveMala();
	NaveMala(int px, int py, int pw, int ph);
	~NaveMala();
};

