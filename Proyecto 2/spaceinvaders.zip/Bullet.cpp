#include "Bullet.h"

Bullet::Bullet()
{

}

Bullet::Bullet(int px, int py, int pw, int ph) : Base(px,py,pw,ph,4,4,0,0)
{
	dx = 10;
}

Bullet::~Bullet()
{
}

void Bullet::Mover(Graphics^ g)
{
	if (x + dx < 1)
	{
		dx = 0;
		Eliminar = true;
	}
	x += dx;
}
