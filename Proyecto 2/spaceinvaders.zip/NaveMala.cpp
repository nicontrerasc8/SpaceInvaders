#include "NaveMala.h"

NaveMala::NaveMala()
{

}

NaveMala::NaveMala(int px, int py, int pw, int ph) : Base(px, py, pw, ph, 3, 7, 0, 0)
{
	x = rand()%1000 + 10;
	y = rand() % 1000 + 10;
	dx = 0;
	dy = rand()% 40 - 20;
}

NaveMala::~NaveMala()
{
}
