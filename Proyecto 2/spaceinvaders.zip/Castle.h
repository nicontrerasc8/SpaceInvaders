#pragma once
#include "Base.h"
class Castle : public Base
{
public:
	Castle();
	Castle(int px, int py, int pw, int ph);
	~Castle();
};

